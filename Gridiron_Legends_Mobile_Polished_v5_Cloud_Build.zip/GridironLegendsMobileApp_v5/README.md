# Gridiron Legends — Mobile v5

Native Android project containing the polished 3D mobile football build.

## Build
Open this folder in Android Studio, let Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The game is bundled locally in `app/src/main/assets/index.html`, so gameplay itself does not require a network connection.

## Phone controls
- Left joystick: move
- PASS: throw to a receiver
- BOOST: sprint burst
- JUKE / SPIN / STIFF: ball-carrier moves
- HIT: defensive/impact action
- CAM: switch field-level follow / broadcast camera
- II: pause

## Visual note
v5 is a polished procedural 3D presentation pass. The player models are original procedural rigs rather than external licensed or scanned assets, and the animation is procedural rather than motion-capture.
