# Gridiron Legends — Cloud Build Ready

This package is prepared for a phone-only cloud build. The included `codemagic.yaml` tells Codemagic to build the Android debug APK and expose the resulting APK as a downloadable artifact.

The game itself is bundled in `app/src/main/assets/index.html` and runs offline inside the Android WebView shell.

Build target: `app/build/outputs/apk/debug/*.apk`
