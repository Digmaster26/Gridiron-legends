# Gridiron Legends — Character & Animation Pass

The Android build now uses a higher-detail procedural 3D character rig instead of box-only players.

Character components:
- torso and shoulder pads
- separate head and helmet volumes
- visor
- facemask bars
- upper arms and forearms
- thighs/shins
- cleats
- hierarchical transforms for animation

Animation layer:
- idle
- run
- sprint/boost
- juke
- spin
- stiff/tackle
- procedural keyframe-style limb motion

Gameplay systems now drive animation state, pursuit, collisions, ball flight and camera shake.

For a commercial-quality art pipeline, optimized original GLB characters and motion-captured clips can be dropped in later without changing the game rules/UI layer.
